package com.example.api_gateway_server;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;

public class SpringCloudConfig {
    @Bean
    public RouteLocator gatewayRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
//Micro-service 1
                .route( "candidatservice",
                        r -> r.path("/candidat/**")
                                .uri("http://localhost:9090/")
         )
         .build();
         }
    }

}
